using $safeprojectname$.Models.Data;

namespace $safeprojectname$
{
    public class Program
    {
        /// <summary>
        /// ���C��
        /// </summary>
        /// <param name="args"></param>
        public static void Main ( string[] args )
        {
            IHost host = CreateHost ( args );
            host.Run ();
        }

        /// <summary>
        /// �z�X�g�쐬
        /// </summary>
        /// <remarks>
        /// 1. �z�X�g�쐬<br/>
        /// 2. appsettings.json�̓ǂݎ��
        /// </remarks>
        /// <param name="args">Main���\�b�h�̈���</param>
        /// <returns>�z�X�g</returns>
        private static IHost CreateHost ( string[] args ) => Host.CreateDefaultBuilder ( args )
            .ConfigureServices ( ( hostContext , services ) =>
            {
                services.Configure<Appsettings> ( hostContext.Configuration.GetSection ( "AppSettings" ) );
                services.AddHostedService<Worker> ();
            } )
            .Build ();
    }
}